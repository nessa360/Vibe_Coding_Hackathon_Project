import React, { useState, useRef } from 'react';
import {
  Mic, Camera, Plus, TrendingUp, TrendingDown,
  DollarSign, FileText, Tag, MicOff, BarChart3, Play, Pause, Volume2
} from 'lucide-react';

// Type definitions
type NewTransaction = {
  type: 'income' | 'expense';
  amount: string;
  description: string;
  category: string;
};

type Transaction = {
  id: number;
  type: 'income' | 'expense';
  amount: number;
  description: string;
  category: string;
  date: string;
  timestamp: Date;
  audioUrl?: string;
};

type AudioRecording = {
  id: number;
  blob: Blob;
  url: string;
  duration: number;
  timestamp: Date;
};

const ExpenseTracker = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [audioRecordings, setAudioRecordings] = useState<AudioRecording[]>([]);
  const [currentView, setCurrentView] = useState('dashboard');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [playingAudio, setPlayingAudio] = useState<number | null>(null);
  const [newTransaction, setNewTransaction] = useState<NewTransaction>({
    type: 'expense',
    amount: '',
    description: '',
    category: 'general'
  });

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  // Totals
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const profit = totalIncome - totalExpenses;

  // Voice recording
  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        
        // Store the audio recording
        const newRecording: AudioRecording = {
          id: Date.now(),
          blob: audioBlob,
          url: audioUrl,
          duration: recordingDuration,
          timestamp: new Date()
        };
        
        setAudioRecordings(prev => [newRecording, ...prev]);
        
        // Create a transaction with audio attachment
        processVoiceInput(audioBlob, audioUrl);
        
        // Clean up
        stream.getTracks().forEach(track => track.stop());
        setRecordingDuration(0);
        if (recordingTimerRef.current) {
          clearInterval(recordingTimerRef.current);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      // Start timer
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      console.error('Microphone access error:', error);
      alert('Microphone access denied. Please enable microphone permissions.');
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Voice processing with stored audio
  const processVoiceInput = (audioBlob: Blob, audioUrl: string) => {
    // Since we can't do real speech-to-text processing, we'll create a transaction
    // that includes the audio recording for manual review
    const mockTransaction = {
      type: 'expense' as 'expense',
      amount: 0, // User will need to fill this in
      description: `Voice memo recorded at ${new Date().toLocaleTimeString()}`,
      category: 'general',
      audioUrl: audioUrl
    };
    
    addTransaction(mockTransaction);
    alert('Voice memo saved! Please review and update the transaction details.');
  };

  const playAudio = async (recordingId: number, audioUrl: string) => {
    if (playingAudio === recordingId) {
      // Stop current audio
      if (audioElementRef.current) {
        audioElementRef.current.pause();
        audioElementRef.current.currentTime = 0;
      }
      setPlayingAudio(null);
      return;
    }

    // Stop any currently playing audio
    if (audioElementRef.current) {
      audioElementRef.current.pause();
    }

    // Create new audio element
    const audio = new Audio(audioUrl);
    audioElementRef.current = audio;
    
    audio.onended = () => {
      setPlayingAudio(null);
    };
    
    audio.onerror = () => {
      console.error('Error playing audio');
      setPlayingAudio(null);
    };

    try {
      await audio.play();
      setPlayingAudio(recordingId);
    } catch (error) {
      console.error('Error playing audio:', error);
      setPlayingAudio(null);
    }
  };

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const mock = {
        type: 'expense' as 'expense',
        amount: 25.5,
        description: 'Office supplies from receipt',
        category: 'supplies'
      };
      addTransaction(mock);
      alert('Receipt processed: $25.50 expense added.');
    }
  };

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'date' | 'timestamp'> & Partial<Transaction>) => {
    const newEntry: Transaction = {
      ...transaction,
      id: Date.now(),
      date: new Date().toLocaleDateString(),
      timestamp: new Date()
    } as Transaction;
    setTransactions(prev => [newEntry, ...prev]);
  };

  const handleManualSubmit = () => {
    if (newTransaction.amount && newTransaction.description) {
      addTransaction({
        ...newTransaction,
        amount: parseFloat(newTransaction.amount)
      });
      setNewTransaction({ type: 'expense', amount: '', description: '', category: 'general' });
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="bg-white shadow-lg border-b border-gray-200">
        <div className="max-w-md mx-auto px-4 py-4">
          <h1 className="text-2xl font-bold text-gray-800 text-center flex items-center justify-center gap-2">
            <DollarSign className="w-6 h-6 text-green-600" /> TradeTracker
          </h1>
        </div>
      </div>

      <div className="max-w-md mx-auto bg-white shadow-sm">
        <div className="flex border-b">
          {['dashboard', 'add', 'history', 'recordings'].map(view => (
            <button
              key={view}
              onClick={() => setCurrentView(view)}
              className={`flex-1 py-3 px-2 text-center font-medium text-xs ${
                currentView === view
                  ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              {view === 'dashboard' ? <BarChart3 className="w-4 h-4 mx-auto mb-1" /> :
               view === 'add' ? <Plus className="w-4 h-4 mx-auto mb-1" /> :
               view === 'history' ? <FileText className="w-4 h-4 mx-auto mb-1" /> :
               <Volume2 className="w-4 h-4 mx-auto mb-1" />}
              {view.charAt(0).toUpperCase() + view.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-md mx-auto bg-white min-h-screen">
        {currentView === 'dashboard' && (
          <div className="p-4 space-y-6">
            <div className="bg-gradient-to-r from-green-500 to-blue-600 rounded-xl p-6 text-white">
              <h2 className="text-lg font-semibold mb-2">Current Profit</h2>
              <div className="text-3xl font-bold mb-2">${profit.toFixed(2)}</div>
              <div className="flex justify-between text-sm opacity-90">
                <span>Income: ${totalIncome.toFixed(2)}</span>
                <span>Expenses: ${totalExpenses.toFixed(2)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium text-green-800">Income</span>
                </div>
                <div className="text-2xl font-bold text-green-600">${totalIncome.toFixed(2)}</div>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingDown className="w-5 h-5 text-red-600" />
                  <span className="text-sm font-medium text-red-800">Expenses</span>
                </div>
                <div className="text-2xl font-bold text-red-600">${totalExpenses.toFixed(2)}</div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-3 text-gray-800">Recent Transactions</h3>
              {recentTransactions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No transactions yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentTransactions.map((t: Transaction) => (
                    <div key={t.id} className="bg-gray-50 rounded-lg p-3 border">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <p className="font-medium text-gray-800 text-sm">{t.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Tag className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-500 capitalize">{t.category}</span>
                            <span className="text-xs text-gray-400">•</span>
                            <span className="text-xs text-gray-500">{t.date}</span>
                            {t.audioUrl && (
                              <>
                                <span className="text-xs text-gray-400">•</span>
                                <Volume2 className="w-3 h-3 text-blue-500" />
                              </>
                            )}
                          </div>
                        </div>
                        <div className={`font-bold text-sm ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                          {t.type === 'income' ? '+' : '-'}${t.amount.toFixed(2)}
                        </div>
                      </div>
                      {t.audioUrl && (
                        <div className="mt-2">
                          <button
                            onClick={() => playAudio(t.id, t.audioUrl!)}
                            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 text-xs"
                          >
                            {playingAudio === t.id ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                            {playingAudio === t.id ? 'Playing...' : 'Play Voice Memo'}
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {currentView === 'add' && (
          <div className="p-4 space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4 text-gray-800">Quick Entry</h3>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={isRecording ? stopVoiceRecording : startVoiceRecording}
                  className={`p-6 rounded-xl border-2 border-dashed ${
                    isRecording ? 'bg-red-50 border-red-300 text-red-600' : 'border-blue-300 text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  {isRecording ? <MicOff className="w-8 h-8 mx-auto mb-2" /> : <Mic className="w-8 h-8 mx-auto mb-2" />}
                  <div className="text-sm font-medium">
                    {isRecording ? 'Stop Recording' : 'Voice Entry'}
                  </div>
                  {isRecording && (
                    <div className="text-xs mt-1 font-mono">
                      {formatDuration(recordingDuration)}
                    </div>
                  )}
                </button>

                <button
                  onClick={() => cameraInputRef.current?.click()}
                  className="p-6 rounded-xl border-2 border-dashed border-green-300 text-green-600 hover:bg-green-50"
                >
                  <Camera className="w-8 h-8 mx-auto mb-2" />
                  <div className="text-sm font-medium">Photo/Receipt</div>
                </button>
                <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" onChange={handlePhotoCapture} className="hidden" />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Transaction Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => setNewTransaction(prev => ({ ...prev, type: 'income' }))}
                    className={`py-2 px-4 rounded-lg font-medium ${newTransaction.type === 'income' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600'}`}>
                    Income
                  </button>
                  <button type="button" onClick={() => setNewTransaction(prev => ({ ...prev, type: 'expense' }))}
                    className={`py-2 px-4 rounded-lg font-medium ${newTransaction.type === 'expense' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-600'}`}>
                    Expense
                  </button>
                </div>
              </div>

              <input
                type="number"
                step="0.01"
                value={newTransaction.amount}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewTransaction((prev: NewTransaction) => ({
                    ...prev,
                    amount: e.target.value
                  }))
                }
                placeholder="Amount ($)"
                required
                className="w-full p-3 border border-gray-300 rounded-lg"
              />

              <input
                type="text"
                value={newTransaction.description}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                  setNewTransaction((prev: NewTransaction) => ({
                    ...prev,
                    description: e.target.value
                  }))
                }
                placeholder="Description"
                required
                className="w-full p-3 border border-gray-300 rounded-lg"
              />

              <select
                value={newTransaction.category}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>) =>
                  setNewTransaction((prev: NewTransaction) => ({
                    ...prev,
                    category: e.target.value
                  }))
                }
                className="w-full p-3 border border-gray-300 rounded-lg"
              >
                <option value="general">General</option>
                <option value="sales">Sales</option>
                <option value="supplies">Supplies</option>
                <option value="transport">Transport</option>
                <option value="rent">Rent</option>
              </select>

              <button onClick={handleManualSubmit} className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700">
                Add Transaction
              </button>
            </div>
          </div>
        )}

        {currentView === 'recordings' && (
          <div className="p-4 space-y-4">
            <h3 className="text-lg font-semibold text-gray-800">Audio Recordings</h3>
            {audioRecordings.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Volume2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No recordings yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {audioRecordings.map((recording) => (
                  <div key={recording.id} className="bg-gray-50 rounded-lg p-4 border">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-800">
                          Recording {recording.timestamp.toLocaleTimeString()}
                        </p>
                        <p className="text-xs text-gray-500">
                          Duration: {formatDuration(recording.duration)}
                        </p>
                      </div>
                      <button
                        onClick={() => playAudio(recording.id, recording.url)}
                        className="flex items-center gap-2 bg-blue-600 text-white px-3 py-2 rounded-lg hover:bg-blue-700"
                      >
                        {playingAudio === recording.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        {playingAudio === recording.id ? 'Pause' : 'Play'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {currentView === 'history' && (
          <div className="p-4 space-y-4">
            <h3 className="text-lg font-semibold text-gray-800">Transaction History</h3>
            {transactions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No transactions yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {transactions.map((t: Transaction) => (
                  <div key={t.id} className="bg-gray-50 rounded-lg p-3 border">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="font-medium text-gray-800 text-sm">{t.description}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Tag className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-500 capitalize">{t.category}</span>
                          <span className="text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">{t.date}</span>
                          {t.audioUrl && (
                            <>
                              <span className="text-xs text-gray-400">•</span>
                              <Volume2 className="w-3 h-3 text-blue-500" />
                            </>
                          )}
                        </div>
                      </div>
                      <div className={`font-bold text-sm ${t.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                        {t.type === 'income' ? '+' : '-'}${t.amount.toFixed(2)}
                      </div>
                    </div>
                    {t.audioUrl && (
                      <div className="mt-2">
                        <button
                          onClick={() => playAudio(t.id, t.audioUrl!)}
                          className="flex items-center gap-2 text-blue-600 hover:text-blue-700 text-xs"
                        >
                          {playingAudio === t.id ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                          {playingAudio === t.id ? 'Playing...' : 'Play Voice Memo'}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExpenseTracker;