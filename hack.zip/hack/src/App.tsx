
import ExpenseTracker from './components/ExpenseTracker'
function App() {
 return <div ><ExpenseTracker /> </div>
}

export default App
